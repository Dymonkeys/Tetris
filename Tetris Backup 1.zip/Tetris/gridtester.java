package Tetris;
import javax.swing.JFrame;

/*
 * File: gridtester.java
 * Author: David Neufeld
 * Created Date: Wed Sep 14 2022 at 2:47:16 PM
 * E-mail: david.neufeld@maine.edu
 * Description:
 * 
 * Collaboration: 
 * 
 */
import java.awt.*;
public class gridtester {
    public static void main(String[] args) {
        GameGrid g = new GameGrid(null);
        JFrame GUI = new JFrame();
        GUI.setBackground(Color.BLACK);
        GUI.setTitle("Vants");
        GUI.setSize(400,620);
        GUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Container pane = GUI.getContentPane();
        pane.add(g);
        GUI.setVisible(true);
        g.state.grid[5][5] = 2;
        g.repaint();
    }
}
